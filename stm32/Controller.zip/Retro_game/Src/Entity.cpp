/*
 * Entity.cpp
 *
 *  Created on: 3 mrt. 2020
 *      Author: bramv
 */

#include "Entity.h"

Entity::Entity() {
	// TODO Auto-generated constructor stub

}

Entity::~Entity() {
	// TODO Auto-generated destructor stub
}

