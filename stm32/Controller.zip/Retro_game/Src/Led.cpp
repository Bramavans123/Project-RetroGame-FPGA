/*
 * Led.cpp
 *
 *  Created on: 19 feb. 2020
 *      Author: bramv
 */

#include "Led.h"

#include "stm32f0xx_hal.h"

Led::Led(GPIO_TypeDef *GPIOx,uint16_t GPIO_Pin) :
	GPIOx(GPIOx),
	GPIO_Pin(GPIO_Pin)
{}

Led::~Led()
{}

void Led::on(void)
{
	HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_SET);
}

void Led::off(void)
{
	HAL_GPIO_WritePin(GPIOx, GPIO_Pin, GPIO_PIN_RESET);
}

