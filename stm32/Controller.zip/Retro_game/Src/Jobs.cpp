/*
 * Jobs.cpp
 *
 *  Created on: 19 feb. 2020
 *      Author: bramv
 */
#include "Jobs.h"
#include "LED.h"

#include "stm32f0xx_hal.h"


/*
 * Blinky LED zijn main functie met C++ code.
 */
void LED()
{
	Led *led1 = new Led(GPIOA,GPIO_PIN_5);

			for(;;)
			{
				led1->on();
				HAL_Delay(2000);
				led1->off();
				HAL_Delay(2000);
			}
}


