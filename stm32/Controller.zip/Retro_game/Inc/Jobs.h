/*
 * Jobs.h
 *
 *  Created on: 19 feb. 2020
 *      Author: bramv
 */

#ifndef JOBS_H_
#define JOBS_H_

#ifdef __cplusplus
extern "C"
{
#endif


void LED();


#ifdef __cplusplus
}
#endif

#endif /* JOBS_H_ */
