/*
 * Entity.h
 *
 *  Created on: 3 mrt. 2020
 *      Author: bramv
 */

#ifndef ENTITY_H_
#define ENTITY_H_

class Entity {
public:
	Entity();
	virtual ~Entity();
};

#endif /* ENTITY_H_ */
