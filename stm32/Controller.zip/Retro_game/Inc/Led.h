/*
 * Led.h
 *
 *  Created on: 19 feb. 2020
 *      Author: bramv
 */

#ifndef LED_H_
#define LED_H_

#include "stm32f0xx_hal.h"

class Led {
public:
	explicit Led(GPIO_TypeDef *GPIOx,uint16_t GPIO_Pin);
	virtual ~Led();
public:
	void on();
	void off();
private:
	GPIO_TypeDef *GPIOx;
	uint16_t GPIO_Pin;
};

#endif /* LED_H_ */
